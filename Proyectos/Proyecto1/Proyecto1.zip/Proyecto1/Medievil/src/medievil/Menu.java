/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Luis Enrique
 */
public class Menu extends JFrame implements ActionListener {

    //ref a clases
    public static Records pnlRecords = new Records();
    public static Tablero pnlTablero = new Tablero();
    public static NJuego pnlJuego = new NJuego();
    
    
    public static JPanel menu = new JPanel();
    

    //botones
    public JButton btnJuego = new JButton("Nuevo Juego");
    public JButton btnRecords = new JButton("Records");
    public JButton btnSalir = new JButton("Salir");
    
    //label fondo
    public JLabel lbFondo = new JLabel();
    
    public JLabel lbTitulo = new JLabel("MEDIEVIL");
    public Menu() {
        
        this.setResizable(false);
        this.setLayout(null);
        this.setTitle("MEDIEVIL");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(950, 700);
        this.setLocationRelativeTo(null);
        
        
        
        menu.setBounds(0, 0, 950, 700);
        menu.setLayout(null);
        lbFondo.setBounds(0, 0, 950, 700);
        //imagen a label
        ImageIcon imagen = new ImageIcon(getClass().getResource("/Imagenes/fondomenu.jpg"));
        Icon fondom = new ImageIcon(imagen.getImage().getScaledInstance(lbFondo.getWidth(), lbFondo.getHeight(), Image.SCALE_DEFAULT));
        lbFondo.setIcon(fondom);
        //botones
        btnJuego.setBounds(410, 350, 150, 30);
        btnJuego.addActionListener(this);
        
        btnRecords.setBounds(410, 380, 150, 30);
        btnRecords.addActionListener(this);
        
        btnSalir.setBounds(410, 410, 150, 30);
        btnSalir.addActionListener(this);
        
        lbTitulo.setBounds(300, 200, 600, 80);
        lbTitulo.setFont(new java.awt.Font("Algerian", 0, 90));
        lbTitulo.setForeground(new java.awt.Color(255, 255, 255));
        
        menu.add(lbTitulo);
        menu.add(btnRecords);
        menu.add(btnSalir);
        menu.add(btnJuego);
        menu.add(lbFondo);
        
        //
        pnlTablero.setBounds(0, 0, 950, 700);
        pnlJuego.setBounds(0, 0, 950, 700);
        
        //añadir paneles
       
        this.add(menu);
        this.add(pnlTablero);
        this.add(pnlJuego);
        this.add(pnlRecords);
        //
        
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        
        //inicar nuevo juego
        if(evento.getSource()==btnJuego){
            menu.setVisible(false);
            pnlJuego.setVisible(true);
        }
        //boton records
        if(evento.getSource()==btnRecords){
            menu.setVisible(false);
            pnlRecords.setVisible(true);
            
        }
        //salir del juego
        if(evento.getSource()==btnSalir){
            System.exit(0);
        }

        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
