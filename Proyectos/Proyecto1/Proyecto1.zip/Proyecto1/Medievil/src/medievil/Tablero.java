/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
//

import static medievil.ControlJuego.vidaJugador1;
import static medievil.ControlJuego.vidaJugador2;

import static medievil.Menu.pnlRecords;
import static medievil.Menu.menu;
import static medievil.NJuego.dimensiones;

//limpiar nuevo juego

import static medievil.NJuego.txfJugador1;
import static medievil.NJuego.txfJugador2;
import static medievil.NJuego.btnMago1;
import static medievil.NJuego.btnPrincesa1;
import static medievil.NJuego.btnGuerrero1;
import static medievil.NJuego.btnMago2;
import static medievil.NJuego.btnPrincesa2;
import static medievil.NJuego.btnGuerrero2;

import static medievil.NJuego.tiempo;

import static medievil.ControlJuego.posicionJugador1X;
import static medievil.ControlJuego.posicionJugador1Y;
import static medievil.ControlJuego.posicionJugador2X;
import static medievil.ControlJuego.posicionJugador2Y;

import static medievil.HiloDado.numeroMovimientos;
import static medievil.ControlJuego.lbMapa;
import static medievil.ControlJuego.dimensionLabelX;
import static medievil.ControlJuego.dimensionLabelY;
/**
 *
 * @author Luis Enrique
 */
public class Tablero extends JPanel implements ActionListener {

    public static JPanel pnlAJuego = new JPanel();
    public static JPanel pnlControles = new JPanel();
    public static ControlJuego controles = new ControlJuego();
    
    public static ArregloJugadores listaJugadores = new ArregloJugadores();
    
    public static int dimensionx = 600;
    public static int dimensiony = 670;

    //controles
    public JLabel lbTiempo = new JLabel("Tiempo");
    public static JLabel lbCronometro = new JLabel();
    public JLabel lbJugador1 = new JLabel("Jugador 1");
    public static JLabel lbNombre1 = new JLabel();
    public JLabel lbJugador2 = new JLabel("Jugador 2");
    public static JLabel lbNombre2 = new JLabel();
    public JLabel lbVidaJugador1 = new JLabel("Vidas");

    public JLabel lbVidaJugador2 = new JLabel("Vidas");

    public JLabel lbPersonajes1 = new JLabel("Pesonajes J1");
    public static JLabel lbPersonaje11 = new JLabel();
    public static JLabel lbPersonaje12 = new JLabel();
    public static JLabel lbPersonaje13 = new JLabel();

    public JLabel lbPersonajes2 = new JLabel("Pesonajes J2");
    public static JLabel lbPersonaje21 = new JLabel();
    public static JLabel lbPersonaje22 = new JLabel();
    public static JLabel lbPersonaje23 = new JLabel();

    public JLabel lbAtaque = new JLabel("Direccion de Movimiento y Ataque");
    public static JLabel lbDado = new JLabel();
    //BOTONES
    public JButton btnTirar = new JButton("Tirar");
    public JButton btnAtacar = new JButton("Atacar");

    public JButton btnArriba = new JButton();
    public JButton btnIzquierda = new JButton();
    public JButton btnAbajo = new JButton();
    public JButton btnDerecha = new JButton();

    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnRecords = new JButton("Ver Records");
    public JButton btnSalir = new JButton("Salir");

    //vidas
    int lbvidax = 30;
    int lbviday = 40;
//
    public int columna = 20;
    public int fila1 = 150;
    public int fila2 = 310;
    public JLabel[][] vidas;
    int filavidasJ1 = 1;
    int filavidasJ2 = 1;
    
    //turno de Jugador
    public static int turno = 0;
   public static int turnoPersonaje1 = 0;
    public  static int turnoPersonaje2 = 0;
    
    //movimientoss
    MovimientoArriba movimientoArriba = new MovimientoArriba();
    MovimientoIzquierda movimientoIzquierda = new MovimientoIzquierda();
    MovimientoAbajo movimientoAbajo = new MovimientoAbajo();
    MovimientoDerecha movimientoDerecha = new MovimientoDerecha();
    
   public int guardado = 0;
    
    public Tablero() {

        this.setSize(950, 700);
        this.setLayout(null);

        //tablero juego
        pnlAJuego.setBounds(0, 0, 600, 700);

        //controles
        pnlControles.setBounds(600, 0, 350, 700);
        pnlControles.setBorder(BorderFactory.createEtchedBorder());
        pnlControles.setLayout(null);
        //labels
        lbTiempo.setBounds(150, 10, 50, 25);
        lbTiempo.setBorder(BorderFactory.createEtchedBorder());
        lbCronometro.setBounds(140, 30, 250, 50);
        lbCronometro.setFont(new java.awt.Font("Arial", 0, 36));
        //lbCronometro.setForeground(new java.awt.Color(255, 255, 255));

        lbJugador1.setBounds(50, 90, 70, 25);
        lbJugador1.setBorder(BorderFactory.createEtchedBorder());
        lbNombre1.setBounds(140, 90, 200, 30);
        lbNombre1.setFont(new java.awt.Font("Arial", 0, 26));
        lbVidaJugador1.setBounds(110, 120, 40, 25);
        lbVidaJugador1.setBorder(BorderFactory.createEtchedBorder());

        vidaJugador1();

        lbPersonajes1.setBounds(260, 90, 85, 25);
        lbPersonajes1.setBorder(BorderFactory.createEtchedBorder());
        lbPersonaje11.setBounds(260, 130, 90, 25);
        lbPersonaje12.setBounds(260, 170, 90, 25);
        lbPersonaje13.setBounds(260, 210, 90, 25);

        //
        lbJugador2.setBounds(50, 250, 70, 25);
        lbJugador2.setBorder(BorderFactory.createEtchedBorder());
        lbNombre2.setBounds(140, 250, 200, 30);
        lbNombre2.setEnabled(false);
        lbNombre2.setFont(new java.awt.Font("Arial", 0, 26));
        lbVidaJugador2.setBounds(110, 280, 40, 25);
        lbVidaJugador2.setBorder(BorderFactory.createEtchedBorder());

        vidaJugador2();

        lbPersonajes2.setBounds(260, 250, 85, 25);
        lbPersonajes2.setBorder(BorderFactory.createEtchedBorder());
        lbPersonaje21.setBounds(260, 290, 90, 25);
        lbPersonaje21.setEnabled(false);
        lbPersonaje22.setBounds(260, 330, 90, 25);
        lbPersonaje22.setEnabled(false);
        lbPersonaje23.setBounds(260, 370, 90, 25);
        lbPersonaje23.setEnabled(false);
        //

        lbAtaque.setBounds(80, 500, 250, 25);

        lbDado.setBounds(100, 400, 50, 100);

        btnTirar.setBounds(200, 430, 100, 30);
        btnTirar.addActionListener(this);
        //botones de direccion
        btnArriba.setBounds(70, 530, 80, 30);
        ImageIcon imagenArriba = new ImageIcon(getClass().getResource("/Imagenes/arriba.png"));
        Icon fondoAR = new ImageIcon(imagenArriba.getImage().getScaledInstance(btnArriba.getWidth(), btnArriba.getHeight(), Image.SCALE_DEFAULT));
        btnArriba.setIcon(fondoAR);
        btnArriba.addActionListener(this);

        btnIzquierda.setBounds(0, 560, 80, 30);
        ImageIcon imagenIzquierda = new ImageIcon(getClass().getResource("/Imagenes/izquierda.png"));
        Icon fondoIZ = new ImageIcon(imagenIzquierda.getImage().getScaledInstance(btnIzquierda.getWidth(), btnIzquierda.getHeight(), Image.SCALE_DEFAULT));
        btnIzquierda.setIcon(fondoIZ);
        btnIzquierda.addActionListener(this);

        btnAbajo.setBounds(70, 590, 80, 30);
        ImageIcon imagenAbajo = new ImageIcon(getClass().getResource("/Imagenes/abajo.png"));
        Icon fondoAB = new ImageIcon(imagenAbajo.getImage().getScaledInstance(btnAbajo.getWidth(), btnAbajo.getHeight(), Image.SCALE_DEFAULT));
        btnAbajo.setIcon(fondoAB);
        btnAbajo.addActionListener(this);

        btnDerecha.setBounds(140, 560, 80, 30);
        ImageIcon imagenDerecha = new ImageIcon(getClass().getResource("/Imagenes/derecha.png"));
        Icon fondoDE = new ImageIcon(imagenDerecha.getImage().getScaledInstance(btnDerecha.getWidth(), btnDerecha.getHeight(), Image.SCALE_DEFAULT));
        btnDerecha.setIcon(fondoDE);
        btnDerecha.addActionListener(this);

        btnAtacar.setBounds(240, 560, 100, 30);
        btnAtacar.setEnabled(false);
        btnAtacar.addActionListener(this);

        btnGuardar.setBounds(10, 640, 100, 30);
        btnGuardar.addActionListener(this);

        btnRecords.setBounds(130, 640, 100, 30);
        btnRecords.setEnabled(false);
        btnRecords.addActionListener(this);

        btnSalir.setBounds(250, 640, 100, 30);
        btnSalir.addActionListener(this);

        //
        pnlControles.add(lbAtaque);
        pnlControles.add(lbTiempo);
        pnlControles.add(lbCronometro);
        pnlControles.add(lbJugador1);
        pnlControles.add(lbNombre1);
        pnlControles.add(lbJugador2);
        pnlControles.add(lbNombre2);
        pnlControles.add(lbVidaJugador1);
        pnlControles.add(lbVidaJugador2);
        pnlControles.add(lbPersonajes1);
        pnlControles.add(lbPersonaje11);
        pnlControles.add(lbPersonaje12);
        pnlControles.add(lbPersonaje13);
        pnlControles.add(lbPersonajes2);
        pnlControles.add(lbPersonaje21);
        pnlControles.add(lbPersonaje22);
        pnlControles.add(lbPersonaje23);
        pnlControles.add(lbDado);

        pnlControles.add(btnTirar);
        pnlControles.add(btnAtacar);
        pnlControles.add(btnArriba);
        pnlControles.add(btnIzquierda);
        pnlControles.add(btnAbajo);
        pnlControles.add(btnDerecha);
        pnlControles.add(btnGuardar);
       // pnlControles.add(btnRecords);
        pnlControles.add(btnSalir);
            
        
        //
        this.add(pnlAJuego);
        this.add(pnlControles);
        
        this.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {

        if (evento.getSource() == btnTirar) {
            ImageIcon imagenD = new ImageIcon(getClass().getResource("/Imagenes/dado.gif"));
            Icon fondoDado = new ImageIcon(imagenD.getImage().getScaledInstance(lbDado.getWidth(), lbDado.getHeight(), Image.SCALE_DEFAULT));
            lbDado.setIcon(fondoDado);

            HiloDado hiloDado = new HiloDado();

            hiloDado.start();
            
            //turnos
            
           
            if(turno == 0){
                lbNombre1.setEnabled(true);
                lbPersonaje11.setEnabled(true);
                lbPersonaje12.setEnabled(true);
                lbPersonaje13.setEnabled(true);
                lbNombre2.setEnabled(false);
                lbPersonaje21.setEnabled(false);
                lbPersonaje22.setEnabled(false);
                lbPersonaje23.setEnabled(false);
               
                
                
            }else if (turno ==1){
                lbNombre2.setEnabled(true);
                lbPersonaje21.setEnabled(true);
                lbPersonaje22.setEnabled(true);
                lbPersonaje23.setEnabled(true);
                lbNombre1.setEnabled(false);
                lbPersonaje11.setEnabled(false);
                lbPersonaje12.setEnabled(false);
                lbPersonaje13.setEnabled(false);
               
                
                       
            }
            turno++;
            if(turno>1){
                turno=0;
            }
          
          btnAtacar.setEnabled(false);
        }

        if (evento.getSource() == btnAtacar) {
                
            
        }

        if (evento.getSource() == btnArriba) {
            if(numeroMovimientos == 0){
                JOptionPane.showMessageDialog(null, "Tire el Dado");
            }else{
                
                movimientoArriba.stop();
                
                movimientoArriba = new MovimientoArriba();
                
                movimientoArriba.start();
                
                btnAtacar.setEnabled(true);
               
            }
        }

        if (evento.getSource() == btnIzquierda) {
            if(numeroMovimientos == 0){
                JOptionPane.showMessageDialog(null, "Tire el Dado");
            }else{
                
                movimientoIzquierda.stop();
                
                movimientoIzquierda = new MovimientoIzquierda();
                
                movimientoIzquierda.start();
                
                btnAtacar.setEnabled(true);
            }
        }

        if (evento.getSource() == btnAbajo) {
            if(numeroMovimientos == 0){
                JOptionPane.showMessageDialog(null, "Tire el Dado");
            }else{
                movimientoAbajo.stop();
                
                movimientoAbajo = new MovimientoAbajo();
                
                movimientoAbajo.start();
                
                btnAtacar.setEnabled(true);
            }
        }

        if (evento.getSource() == btnDerecha) {
            if(numeroMovimientos == 0){
                JOptionPane.showMessageDialog(null, "Tire el Dado");
            }else{
                movimientoDerecha.stop();
                
                movimientoDerecha = new MovimientoDerecha();
                
                movimientoDerecha.start();
                
                btnAtacar.setEnabled(true);
            }
        }

        if (evento.getSource() == btnGuardar) {
               guardado++;
             int resp = JOptionPane.showConfirmDialog(null, "¿Esta seguro?", "Alerta!", JOptionPane.YES_NO_OPTION);
             if(resp == 0){
            listaJugadores.agregarJugador(lbNombre1.getText(), lbPersonaje11.getText(), lbPersonaje12.getText(), lbPersonaje13.getText(), vidaJugador1, lbCronometro.getText());
            listaJugadores.agregarJugador(lbNombre2.getText(), lbPersonaje21.getText(), lbPersonaje22.getText(), lbPersonaje23.getText(), vidaJugador2, lbCronometro.getText());
            //listaJugadores.mostrarjugadores();
            
            btnGuardar.setEnabled(false);
             }else{
                 
             }
            
            
        }   

       

        if (evento.getSource() == btnSalir) {
            
            
            if(guardado == 1){
                //JOptionPane.showMessageDialog(null, "");
            }else{
                 JOptionPane.showMessageDialog(null, "No se Guardara esta Partida", "Alerta de Guardado", JOptionPane.WARNING_MESSAGE);
            }
           
            guardado = 0;
            btnGuardar.setEnabled(true);
            this.setVisible(false);
            // limpiar datos NJ
            pnlAJuego.removeAll();
            txfJugador1.setText("");
            txfJugador2.setText("");
            btnMago1.setEnabled(true);
            btnMago2.setEnabled(true);
            btnPrincesa1.setEnabled(true);
            btnPrincesa2.setEnabled(true);
            btnGuerrero1.setEnabled(true);
            btnGuerrero2.setEnabled(true);
            tiempo.stop();
            lbDado.setIcon(null);
            menu.setVisible(true);

        }
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void vidaJugador1() {

        if (vidaJugador1 > 7 || vidaJugador1 > 14) {
            filavidasJ1++;
        }
        ImageIcon imagenV1 = new ImageIcon(getClass().getResource("/Imagenes/vida.png"));
        Icon fondoVIDA1 = new ImageIcon(imagenV1.getImage().getScaledInstance(lbvidax, lbviday, Image.SCALE_DEFAULT));
        vidas = new JLabel[3][7];

        for (int i = 0; i < filavidasJ1; i++) {
            for (int j = 0; j < vidaJugador1; j++) {

                vidas[i][j] = new JLabel();
                vidas[i][j].setSize(lbvidax, lbviday);
                vidas[i][j].setOpaque(false);
                vidas[i][j].setIcon(fondoVIDA1);
                pnlControles.add(vidas[i][j]);

                vidas[i][j].setLocation(columna, fila1);
                columna += lbvidax;
            }
            if (columna == lbvidax * 7) {
                columna = 30;
            }
            fila1 += lbviday;

        }
    }

    public void vidaJugador2() {

        if (vidaJugador2 > 7 || vidaJugador2 > 14) {
            filavidasJ2++;
        }
        ImageIcon imagenV2 = new ImageIcon(getClass().getResource("/Imagenes/vida.png"));
        Icon fondoVIDA2 = new ImageIcon(imagenV2.getImage().getScaledInstance(lbvidax, lbviday, Image.SCALE_DEFAULT));
        vidas = new JLabel[3][7];
        columna = 20;
        for (int i = 0; i < filavidasJ2; i++) {
            for (int j = 0; j < vidaJugador2; j++) {

                vidas[i][j] = new JLabel();
                vidas[i][j].setSize(lbvidax, lbviday);
                vidas[i][j].setOpaque(false);
                vidas[i][j].setIcon(fondoVIDA2);
                pnlControles.add(vidas[i][j]);

                vidas[i][j].setLocation(columna, fila2);
                columna += lbvidax;
            }
            if (columna == lbvidax * 7) {
                columna = 30;
            }
            fila1 += lbviday;

        }
    }
    // terminar el juego 
    public void Juego(){
        
        int vidaJ1 = 5;
        int vidaJ2 = 5;
        String tiempoJ = "4:59";
        
        vidaJ1 = vidaJugador1;
        vidaJ2 = vidaJugador2;
        tiempoJ = lbCronometro.getText();
        
        
        if(vidaJ1 == 0 || vidaJ2 == 0 || tiempoJ.equals("0:0")){
            
            
            listaJugadores.agregarJugador(lbNombre1.getText(), lbPersonaje11.getText(), lbPersonaje12.getText(), lbPersonaje13.getText(), vidaJugador1, lbCronometro.getText());
            listaJugadores.agregarJugador(lbNombre2.getText(), lbPersonaje21.getText(), lbPersonaje22.getText(), lbPersonaje23.getText(), vidaJugador2, lbCronometro.getText());
            
            if(vidaJ1>vidaJ2){
                
                JOptionPane.showMessageDialog(null, "Ganador "+lbNombre1.getText());
            }else if(vidaJ2 > vidaJ1){
                JOptionPane.showMessageDialog(null, "Ganador "+lbNombre2.getText());
            }else if(vidaJ1 == vidaJ2){
                JOptionPane.showMessageDialog(null, "Empate");
            }
            
            guardado = 0;
            btnGuardar.setEnabled(true);
            this.setVisible(false);
            // limpiar datos NJ
            pnlAJuego.removeAll();
            txfJugador1.setText("");
            txfJugador2.setText("");
            btnMago1.setEnabled(true);
            btnMago2.setEnabled(true);
            btnPrincesa1.setEnabled(true);
            btnPrincesa2.setEnabled(true);
            btnGuerrero1.setEnabled(true);
            btnGuerrero2.setEnabled(true);
            tiempo.stop();
            lbDado.setIcon(null);
            menu.setVisible(true);
        }
    }
    
  /*  public Icon turnosJ1(){
        
        String imagenP1  = "";
        
        
        switch (turnoPersonaje1){
            case 0:
                if(lbPersonaje11.getText().equals("Mago")){
                    imagenP1 = "/Imagenes/mago.png";
                }else if(lbPersonaje11.getText().equals("Princesa")){
                    imagenP1 = "/Imagenes/princesa.png";
                }else{
                    imagenP1 = "/Imagenes/caballero.png";
                }
                break;
            case 1:
                if(lbPersonaje12.getText().equals("Mago")){
                    imagenP1 = "/Imagenes/mago.png";
                }else if(lbPersonaje12.getText().equals("Princesa")){
                    imagenP1 = "/Imagenes/princesa.png";
                }else{
                    imagenP1 = "/Imagenes/caballero.png";
                }
                break;
            case 2:
                if(lbPersonaje13.getText().equals("Mago")){
                    imagenP1 = "/Imagenes/mago.png";
                }else if(lbPersonaje13.getText().equals("Princesa")){
                    imagenP1 = "/Imagenes/princesa.png";
                }else{
                    imagenP1 = "/Imagenes/caballero.png";
                }
                break;
        }
        
        ImageIcon imagenJ1 = new ImageIcon(getClass().getResource(imagenP1));
        Icon fondoJ1 = new ImageIcon(imagenJ1.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        turnoPersonaje1++;
        if(turnoPersonaje1>2){
            turnoPersonaje1=0;
        }
        return fondoJ1;
    }
    
    public Icon turnosJ2(){
        
        String imagenP2  = "";
        
        
        switch (turnoPersonaje2){
            case 0:
                if(lbPersonaje21.getText().equals("Mago")){
                    imagenP2 = "/Imagenes/mago2.png";
                }else if(lbPersonaje21.getText().equals("Princesa")){
                    imagenP2 = "/Imagenes/princesa2.png";
                }else{
                    imagenP2 = "/Imagenes/caballero2.png";
                }
                break;
            case 1:
                if(lbPersonaje22.getText().equals("Mago")){
                    imagenP2 = "/Imagenes/mago2.png";
                }else if(lbPersonaje22.getText().equals("Princesa")){
                    imagenP2 = "/Imagenes/princesa2.png";
                }else{
                    imagenP2 = "/Imagenes/caballero2.png";
                }
                break;
            case 2:
                if(lbPersonaje23.getText().equals("Mago")){
                    imagenP2 = "/Imagenes/mago2.png";
                }else if(lbPersonaje23.getText().equals("Princesa")){
                    imagenP2 = "/Imagenes/princesa2.png";
                }else{
                    imagenP2 = "/Imagenes/caballero2.png";
                }
                break;
        }
        
        ImageIcon imagenJ1 = new ImageIcon(getClass().getResource(imagenP2));
        Icon fondoJ2 = new ImageIcon(imagenJ1.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        turnoPersonaje2++;
        if(turnoPersonaje2>2){
            turnoPersonaje2=0;
        }
        return fondoJ2;
    }*/
}
