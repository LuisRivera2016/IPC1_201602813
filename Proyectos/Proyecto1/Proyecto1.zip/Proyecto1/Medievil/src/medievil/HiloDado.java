/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

import java.awt.Image;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import static medievil.Tablero.lbDado;
/**
 *
 * @author Luis Enrique
 */
public class HiloDado extends Thread{
    
    public Random pos  = new Random();
    public static int numeroMovimientos = 0;
    
    public String imagen;
    
    public int segundos;
    public void run(){
        
        
        
        for (int i = 0; i < 2; i++) {
            segundos++;
             try {
            Thread.sleep(500);
        } catch (InterruptedException ex) {
            Logger.getLogger(HiloDado.class.getName()).log(Level.SEVERE, null, ex);
        }
            if(segundos == 2 ){
           imagenDado();
       } 
        }
           
                
        
        
        
    }
    
    public void imagenDado(){
        
        
        
        numeroMovimientos = pos.nextInt(6)+1;
        
        switch (numeroMovimientos){
            case 1 :
                imagen = "/Imagenes/1.png";
                
                break;
            case 2 :
                imagen = "/Imagenes/2.png";
              
                break; 
            case 3 :
                imagen = "/Imagenes/3.png";
               
                break;
            case 4 :
                imagen = "/Imagenes/4.png";
               
                break;
            case 5 :
                imagen = "/Imagenes/5.png";
               
                break;    
            case 6 :
                imagen = "/Imagenes/6.png";
                
                break; 
            default :
                imagen = "/Imagenes/6.png";
                
                
        }
        
        ImageIcon imagenDado = new ImageIcon(getClass().getResource(imagen));
        Icon fondoD = new ImageIcon(imagenDado.getImage().getScaledInstance(lbDado.getWidth(), lbDado.getHeight(), Image.SCALE_DEFAULT));
        lbDado.setIcon(fondoD);
        
    }
    
}
