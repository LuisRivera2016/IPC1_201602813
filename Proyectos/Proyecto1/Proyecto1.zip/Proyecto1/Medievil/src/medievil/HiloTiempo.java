/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;


import java.util.logging.Level;
import java.util.logging.Logger;
import static medievil.Tablero.lbCronometro;
import static medievil.Menu.pnlTablero;
/**
 *
 * @author Luis Enrique
 */
public class HiloTiempo extends Thread{
    
    
    int centesima = 100;
    int segundo = 59;
    int minutos = 4;
    
    
    public void run(){
        
        
        while(minutos>0){
         try {
            Thread.sleep(10);
        } catch (InterruptedException ex) {
            Logger.getLogger(HiloDado.class.getName()).log(Level.SEVERE, null, ex);
        }
         
          centesima--;
                if (centesima<=0){
                    centesima = 100;
                    segundo--;
                }
                if (segundo<=0){
                    segundo = 59;
                    minutos--;
                }
 
                
        lbCronometro.setText(minutos+":"+segundo);
        pnlTablero.Juego();
        pnlTablero.repaint();
        }
    }
    
}
