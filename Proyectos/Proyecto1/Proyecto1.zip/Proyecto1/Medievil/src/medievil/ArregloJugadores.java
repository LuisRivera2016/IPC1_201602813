/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

/**
 *
 * @author Luis Enrique
 */
public class ArregloJugadores {
    
    public Jugador[] arregloJugador;
    
    public static String [] Listadojugadores  = new String[4];
    
    int contador = 0 ;
    
    public ArregloJugadores(){
        
        arregloJugador = new Jugador[100+contador];
    }
    
    public void agregarJugador(String nombre, String personaje1, String personaje2, String personaje3, int vidas , String tiempo){
        Jugador jugador = new Jugador();
        jugador.setNombre(nombre);
        jugador.setPersonaje1(personaje1);
        jugador.setPersonaje2(personaje2);
        jugador.setPersonaje3(personaje3);
        jugador.setVidas(vidas);
        jugador.setTiempo(tiempo);
      // jugador.setPosicion(posicion);
        
        arregloJugador [contador]= jugador;
        contador++;
        
        //
        
        Listadojugadores[0]= jugador.getNombre();
        Listadojugadores[1] = "1."+jugador.getPersonaje1()+" 2."+jugador.getPersonaje2()+" 3."+jugador.getPersonaje3();
        Listadojugadores[2] = Integer.toString(jugador.getVidas());
        Listadojugadores[3] = jugador.getTiempo();
       
   
        
    }
    
    public void mostrarjugadores(){
        
        for (int i = 0; i < contador; i++) {
            System.out.println(arregloJugador[i].getNombre());
            System.out.println(arregloJugador[i].getPersonaje1()+" "+arregloJugador[i].getPersonaje2()+" "+arregloJugador[i].getPersonaje3());
            System.out.println(arregloJugador[i].getVidas());
            System.out.println(arregloJugador[i].getTiempo());
        }
    }
    
}
