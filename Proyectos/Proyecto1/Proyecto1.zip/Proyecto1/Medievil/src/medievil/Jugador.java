/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

/**
 *
 * @author Luis Enrique
 */
public class Jugador {
    
    public String nombre;
    public String personaje1;
    public String personaje2;
    public String personaje3;
    public int vidas;
    public String tiempo;
    //public int [][] posicion;
    
    
    public Jugador(){
        nombre = "";
        personaje1 = "";
        personaje2 = "";
        personaje3 = "";
        vidas = 5;
        tiempo = "";
        //posicion = new int[0][0];
        
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPersonaje1() {
        return personaje1;
    }

    public void setPersonaje1(String personaje1) {
        this.personaje1 = personaje1;
    }

    public String getPersonaje2() {
        return personaje2;
    }

    public void setPersonaje2(String personaje2) {
        this.personaje2 = personaje2;
    }

    public String getPersonaje3() {
        return personaje3;
    }

    public void setPersonaje3(String personaje3) {
        this.personaje3 = personaje3;
    }

    public int getVidas() {
        return vidas;
    }

    public void setVidas(int vidas) {
        this.vidas = vidas;
    }

    public String getTiempo() {
        return tiempo;
    }

    public void setTiempo(String tiempo) {
        this.tiempo = tiempo;
    }

    

    
    
    
    
}
