/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
//imports

import static medievil.Menu.pnlTablero;
import static medievil.Tablero.controles;

import static medievil.Tablero.lbNombre1;
import static medievil.Tablero.lbNombre2;
import static medievil.Tablero.lbPersonaje11;
import static medievil.Tablero.lbPersonaje12;
import static medievil.Tablero.lbPersonaje13;
import static medievil.Tablero.lbPersonaje21;
import static medievil.Tablero.lbPersonaje22;
import static medievil.Tablero.lbPersonaje23;

/**
 *
 * @author Luis Enrique
 */
public class NJuego extends JPanel implements ActionListener{
    
    public JLabel lbFondo = new JLabel();
    public JLabel lbJugador1 = new JLabel("Nombre Jugador 1: ");
    public JLabel lbJugador2 = new JLabel("Nombre Jugador 2: ");
    public JLabel lbOrden1 = new  JLabel("Seleccione el Orden de sus Personajes");
    public JLabel lbOrdenj1 = new  JLabel("Jugador 1");
    public JLabel lbOrdenj2 = new  JLabel("Jugador 2");
    
    public static JButton btnMago1 = new JButton();
    public static JButton btnPrincesa1 = new JButton();
    public static JButton btnGuerrero1 = new JButton();
    public static JButton btnMago2 = new JButton();
    public static JButton btnPrincesa2 = new JButton();
    public static JButton btnGuerrero2 = new JButton();
    public JButton btnContinuar = new JButton("Iniciar");
    
    public static JTextField txfJugador1 = new JTextField();
    public static JTextField txfJugador2 = new JTextField();
    
    
    //variables juego
    
    public static int dimensiones = 0;
    public static HiloTiempo tiempo = new HiloTiempo();
    public NJuego(){
        
        this.setSize(950, 700);
        this.setLayout(null);
        
        lbFondo.setBounds(0, 0, 950, 700);
        //imagen a label
        ImageIcon imagen = new ImageIcon(getClass().getResource("/Imagenes/fondo3.jpg"));
        Icon fondom = new ImageIcon(imagen.getImage().getScaledInstance(lbFondo.getWidth(), lbFondo.getHeight(), Image.SCALE_DEFAULT));
        lbFondo.setIcon(fondom);
        //labels nombre
        lbJugador1.setBounds(150, 30,250, 30);
        lbJugador1.setFont(new java.awt.Font("Algerian", 0, 20));
       // lbJugador1.setForeground(new java.awt.Color(255, 255, 255));
        
        lbJugador2.setBounds(650, 30,250, 30);
        lbJugador2.setFont(new java.awt.Font("Algerian", 0, 20));
       // lbJugador1.setForeground(new java.awt.Color(255, 255, 255));
        
        lbOrden1.setBounds(290, 150,400, 30);
        lbOrden1.setFont(new java.awt.Font("Algerian", 0, 20));
       // lbJugador1.setForeground(new java.awt.Color(255, 255, 255));
        
        lbOrdenj1.setBounds(180, 200,400, 30);
        lbOrdenj1.setFont(new java.awt.Font("Algerian", 0, 20));
        
        lbOrdenj2.setBounds(680, 200,400, 30);
        lbOrdenj2.setFont(new java.awt.Font("Algerian", 0, 20));
        //
        //textfield
        txfJugador1.setBounds(150, 60, 200, 40);
        txfJugador2.setBounds(650, 60, 200, 40);
        //
        //botones personajes
        btnMago1.setBounds(100, 230, 100, 200);
        btnMago1.setContentAreaFilled(false);
        ImageIcon imagenMago1 = new ImageIcon(getClass().getResource("/Imagenes/mago.png"));
        Icon fondomM1 = new ImageIcon(imagenMago1.getImage().getScaledInstance(btnMago1.getWidth(), btnMago1.getHeight(), Image.SCALE_DEFAULT));
        btnMago1.setIcon(fondomM1);
        btnMago1.addActionListener(this);
        
        btnPrincesa1.setBounds(210, 230, 100, 200);
        btnPrincesa1.setContentAreaFilled(false);
        ImageIcon imagenPrincesa1 = new ImageIcon(getClass().getResource("/Imagenes/princesa.png"));
        Icon fondomP1 = new ImageIcon(imagenPrincesa1.getImage().getScaledInstance(btnMago1.getWidth(), btnMago1.getHeight(), Image.SCALE_DEFAULT));
        btnPrincesa1.setIcon(fondomP1);
        btnPrincesa1.addActionListener(this);
        
        btnGuerrero1.setBounds(320, 230, 100, 200);
        btnGuerrero1.setContentAreaFilled(false);
        ImageIcon imagenGuerrero1 = new ImageIcon(getClass().getResource("/Imagenes/caballero.png"));
        Icon fondomG1 = new ImageIcon(imagenGuerrero1.getImage().getScaledInstance(btnMago1.getWidth(), btnMago1.getHeight(), Image.SCALE_DEFAULT));
        btnGuerrero1.setIcon(fondomG1);
        btnGuerrero1.addActionListener(this);
        
        btnMago2.setBounds(600, 230, 100, 200);
        btnMago2.setContentAreaFilled(false);
        ImageIcon imagenMago2 = new ImageIcon(getClass().getResource("/Imagenes/mago2.png"));
        Icon fondomM2 = new ImageIcon(imagenMago2.getImage().getScaledInstance(btnMago1.getWidth(), btnMago1.getHeight(), Image.SCALE_DEFAULT));
        btnMago2.setIcon(fondomM2);
        btnMago2.addActionListener(this);
        
        btnPrincesa2.setBounds(710, 230, 100, 200);
        btnPrincesa2.setContentAreaFilled(false);
        ImageIcon imagenPrincesa2 = new ImageIcon(getClass().getResource("/Imagenes/princesa2.png"));
        Icon fondomP2 = new ImageIcon(imagenPrincesa2.getImage().getScaledInstance(btnMago1.getWidth(), btnMago1.getHeight(), Image.SCALE_DEFAULT));
        btnPrincesa2.setIcon(fondomP2);
        btnPrincesa2.addActionListener(this);
        
        btnGuerrero2.setBounds(820, 230, 100, 200);
        btnGuerrero2.setContentAreaFilled(false);
        ImageIcon imagenGuerrero2 = new ImageIcon(getClass().getResource("/Imagenes/caballero2.png"));
        Icon fondomG2 = new ImageIcon(imagenGuerrero2.getImage().getScaledInstance(btnMago1.getWidth(), btnMago1.getHeight(), Image.SCALE_DEFAULT));
        btnGuerrero2.setIcon(fondomG2);
        btnGuerrero2.addActionListener(this);
        
        
        btnContinuar.setBounds(420, 500, 150, 40);
        btnContinuar.addActionListener(this);
        
        this.add(btnContinuar);
        this.add(btnMago1);
        this.add(btnGuerrero1);
        this.add(btnPrincesa1);
        this.add(btnMago2);
        this.add(btnGuerrero2);
        this.add(btnPrincesa2);
        
        
        this.add(txfJugador1);
        this.add(txfJugador2);
        
        this.add(lbOrdenj2);
        this.add(lbOrden1);
        this.add(lbOrdenj1);
        this.add(lbJugador2);
        this.add(lbJugador1);
        
        this.add(lbFondo);
        
        this.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        
        
        if(evento.getSource()==btnContinuar){
            lbNombre1.setText(txfJugador1.getText());
            lbNombre2.setText(txfJugador2.getText());
            if(txfJugador1.getText().trim().equals("") || txfJugador2.getText().trim().equals("") || lbNombre1.getText().equals("")
                    || lbNombre2.getText().equals("") || lbPersonaje11.getText().equals("") || lbPersonaje12.getText().equals("")
                    || lbPersonaje13.getText().equals("") || lbPersonaje21.getText().equals("") || lbPersonaje22.getText().equals("")
                   || lbPersonaje23.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Debe Ingresar todos los Datos y Seleccionar todos los Personajes", "Error", JOptionPane.WARNING_MESSAGE);
                
                
            }else{
                
                String respuesta = JOptionPane.showInputDialog(null, "Escriba las dimensiones del Tablero");
                dimensiones =  Integer.parseInt(respuesta);
                if(dimensiones>=8 && dimensiones <=18){
                    
                    this.setVisible(false);
                    pnlTablero.setVisible(true);
                      
                    controles.tableroJuego();
                    if(tiempo.isAlive()){
                        tiempo = new HiloTiempo();
                        tiempo.start();
                        
                    }else{
                        
                        tiempo = new HiloTiempo();
                        tiempo.start();
                     
                    }
                    
                       
                    
                }else{
                    	
                 respuesta = JOptionPane.showInputDialog(null, "Escriba dimensiones entre 8 y 18", "Error!", JOptionPane.ERROR_MESSAGE);
                 dimensiones =  Integer.parseInt(respuesta);
                 this.setVisible(false);
                 pnlTablero.setVisible(true);
           
                 controles.tableroJuego();
                   if(tiempo.isAlive()){
                        tiempo = new HiloTiempo();
                        tiempo.start();
                       
                    }else{
                        
                        tiempo = new HiloTiempo();
                        tiempo.start();
                        
                    }
                 
                  
                  
                }
                    
            
            } 
        }
        
        if(evento.getSource()==btnMago1){
            btnMago1.setEnabled(false);
            if(lbPersonaje11.getText().equals("")){
                lbPersonaje11.setText("Mago");
            }else if(lbPersonaje12.getText().equals("")){
                lbPersonaje12.setText("Mago");
            }else {
                lbPersonaje13.setText("Mago");
            }
            
        }
        
        if(evento.getSource()==btnPrincesa1){
            btnPrincesa1.setEnabled(false);
            if(lbPersonaje11.getText().equals("")){
                lbPersonaje11.setText("Princesa");
            }else if(lbPersonaje12.getText().equals("")){
                lbPersonaje12.setText("Princesa");
            }else {
                lbPersonaje13.setText("Princesa");
            }
        }
        
        if(evento.getSource()==btnGuerrero1){
            btnGuerrero1.setEnabled(false);
            if(lbPersonaje11.getText().equals("")){
                lbPersonaje11.setText("Guerrero");
            }else if(lbPersonaje12.getText().equals("")){
                lbPersonaje12.setText("Guerrero");
            }else {
                lbPersonaje13.setText("Guerrero");
            }
        }
        
        if(evento.getSource()==btnMago2){
            btnMago2.setEnabled(false);
            if(lbPersonaje21.getText().equals("")){
                lbPersonaje21.setText("Mago");
            }else if(lbPersonaje22.getText().equals("")){
                lbPersonaje22.setText("Mago");
            }else {
                lbPersonaje23.setText("Mago");
            }
        }
        
        if(evento.getSource()==btnPrincesa2){
            btnPrincesa2.setEnabled(false);
            if(lbPersonaje21.getText().equals("")){
                lbPersonaje21.setText("Princesa");
            }else if(lbPersonaje22.getText().equals("")){
                lbPersonaje22.setText("Princesa");
            }else {
                lbPersonaje23.setText("Princesa");
            }
        }
        
        if(evento.getSource()==btnGuerrero2){
            btnGuerrero2.setEnabled(false);
            if(lbPersonaje21.getText().equals("")){
                lbPersonaje21.setText("Guerrero");
            }else if(lbPersonaje22.getText().equals("")){
                lbPersonaje22.setText("Guerrero");
            }else {
                lbPersonaje23.setText("Guerrero");
            }
        }
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void comparar(){
        
       
    }
    
}
