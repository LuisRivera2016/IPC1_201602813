/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;




//
import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import static medievil.Tablero.pnlAJuego;
import static medievil.NJuego.dimensiones;
import static medievil.Tablero.dimensionx;
import static medievil.Tablero.dimensiony;

import static medievil.Tablero.lbPersonaje11;
import static medievil.Tablero.lbPersonaje12;
import static medievil.Tablero.lbPersonaje13;
import static medievil.Tablero.lbPersonaje21;
import static medievil.Tablero.lbPersonaje22;
import static medievil.Tablero.lbPersonaje23;
import static medievil.Tablero.pnlAJuego;

//variables de control
import static medievil.HiloDado.numeroMovimientos;
/**
 *
 * @author Luis Enrique
 * 
 */
public class ControlJuego {

    public static int dimensionLabelX;
    public static int dimensionLabelY;

    public int numeroVidas;
    public int numeroBombas;

    public static JLabel[][] lbMapa;

    //fondo
    public JLabel lbFondo = new JLabel();
    public String imagenJugador;
    
    
    //posiciones aux JUGADORES
   public static int posicionJugador1X ;
   public static int posicionJugador1Y;
    
    public static int posicionJugador2X ;
    public static int posicionJugador2Y;
    
    //
    public static int vidaJugador1 = 5;
    public static int vidaJugador2 = 5;
    
    public void tableroJuego() {

        lbMapa = new JLabel[dimensiones][dimensiones];
        int fila = 0;
        int columna = 0;

        dimensionLabelX = dimensionx / dimensiones;
        dimensionLabelY = dimensiony / dimensiones;
        //crecaion de tablero de labels  
        for (int i = 0; i < lbMapa.length; i++) {
            for (int j = 0; j < lbMapa.length; j++) {

                lbMapa[i][j] = new JLabel();
                lbMapa[i][j].setSize(dimensionLabelX, dimensionLabelY);
                lbMapa[i][j].setOpaque(false);
                lbMapa[i][j].setBorder(BorderFactory.createLineBorder(Color.white));
                pnlAJuego.add(lbMapa[i][j]);

                lbMapa[i][j].setLocation(columna, fila);
                columna += dimensionLabelX;
            }
            if (columna == dimensionLabelX * dimensiones) {
                columna = 0;
            }
            fila += dimensionLabelY;

        }

        // colocar vidas
        numeroVidas = (int) ((dimensiones * dimensiones) * 0.05);
        ImageIcon imagenV = new ImageIcon(getClass().getResource("/Imagenes/vida.png"));
        Icon fondoV = new ImageIcon(imagenV.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        for (int i = 0; i < numeroVidas; i++) {

            Random pos = new Random();
            int x = pos.nextInt(dimensiones - 1) + 1;
            int y = pos.nextInt(dimensiones - 1) + 1;
            lbMapa[x][y].setIcon(fondoV);

        }

        // colocar bombas
        numeroBombas = (int) ((dimensiones * dimensiones) * 0.1);
        ImageIcon imagenB = new ImageIcon(getClass().getResource("/Imagenes/bomba.png"));
        Icon fondoB = new ImageIcon(imagenB.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        for (int i = 0; i < numeroBombas; i++) {

            Random pos = new Random();
            int x = pos.nextInt(dimensiones - 1) + 1;
            int y = pos.nextInt(dimensiones - 1) + 1;
            if (lbMapa[x][y].getIcon() == null) {
                lbMapa[x][y].setIcon(fondoB);
            } else {
                i--;
            }

        }

        // colocar jugadores
        //colocar JUGADOR1
        imagenJugador1();
        ImageIcon imagenJ = new ImageIcon(getClass().getResource(imagenJugador));
        Icon fondoJ = new ImageIcon(imagenJ.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        for (int i = 0; i <1; i++) {

            Random pos = new Random();
            int x = pos.nextInt(dimensiones - 1) + 1;
            int y = pos.nextInt(dimensiones - 1) + 1;
            if (lbMapa[x][y].getIcon() == null) {
                lbMapa[x][y].setIcon(fondoJ);
               // obteniendo posicion del jugador 1
                posicionJugador1X = x;
                posicionJugador1Y = y;
            } else {
                i--;
            }

        }
        
        //colocar JUGADOR2
        imagenJugador2();
        ImageIcon imagenJ2 = new ImageIcon(getClass().getResource(imagenJugador));
        Icon fondoJ2 = new ImageIcon(imagenJ2.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        for (int i = 0; i <1; i++) {

            Random pos = new Random();
            int x = pos.nextInt(dimensiones - 1) + 1;
            int y = pos.nextInt(dimensiones - 1) + 1;
            if (lbMapa[x][y].getIcon() == null) {
                lbMapa[x][y].setIcon(fondoJ2); 
                // obteniendo posicion del jugador 2
                posicionJugador2X = x;
                posicionJugador2Y = y;
            } else {
                i--;
            }

        }
                
        //fondo
        lbFondo.setBounds(0, 0, 600, 700);
        //imagen a label
        ImageIcon imagen = new ImageIcon(getClass().getResource("/Imagenes/fondo.jpg"));
        Icon fondom = new ImageIcon(imagen.getImage().getScaledInstance(lbFondo.getWidth(), lbFondo.getHeight(), Image.SCALE_DEFAULT));
        lbFondo.setIcon(fondom);
        pnlAJuego.setLayout(null);
        pnlAJuego.add(lbFondo);
    }
    
    public void imagenJugador1(){
        
        if(lbPersonaje11.getText().equals("Mago")){
            imagenJugador = "/Imagenes/mago.png";
        }else if(lbPersonaje11.getText().equals("Princesa")){
            imagenJugador = "/Imagenes/princesa.png";
        }else{
            imagenJugador = "/Imagenes/caballero.png";
        }
    }
    
     public void imagenJugador2(){
        
        if(lbPersonaje21.getText().equals("Mago")){
            imagenJugador = "/Imagenes/mago2.png";
        }else if(lbPersonaje21.getText().equals("Princesa")){
            imagenJugador = "/Imagenes/princesa2.png";
        }else{
            imagenJugador = "/Imagenes/caballero2.png";
        }
    }
     
     
     
}
