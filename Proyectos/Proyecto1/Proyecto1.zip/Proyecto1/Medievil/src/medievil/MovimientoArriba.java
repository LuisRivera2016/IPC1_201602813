/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;



import java.awt.Image;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import static medievil.ControlJuego.dimensionLabelX;
import static medievil.ControlJuego.dimensionLabelY;
import static medievil.ControlJuego.lbMapa;
import static medievil.ControlJuego.vidaJugador1;
import static medievil.ControlJuego.vidaJugador2;

import static medievil.Menu.pnlRecords;
import static medievil.Menu.menu;
import static medievil.NJuego.dimensiones;

//limpiar nuevo juego

import static medievil.NJuego.txfJugador1;
import static medievil.NJuego.txfJugador2;
import static medievil.NJuego.btnMago1;
import static medievil.NJuego.btnPrincesa1;
import static medievil.NJuego.btnGuerrero1;
import static medievil.NJuego.btnMago2;
import static medievil.NJuego.btnPrincesa2;
import static medievil.NJuego.btnGuerrero2;

import static medievil.NJuego.tiempo;

import static medievil.ControlJuego.posicionJugador1X;
import static medievil.ControlJuego.posicionJugador1Y;
import static medievil.ControlJuego.posicionJugador2X;
import static medievil.ControlJuego.posicionJugador2Y;

import static medievil.HiloDado.numeroMovimientos;
import static medievil.ControlJuego.posicionJugador1X;
import static medievil.ControlJuego.posicionJugador1Y;
import static medievil.ControlJuego.posicionJugador2X;
import static medievil.ControlJuego.posicionJugador2Y;
import static medievil.HiloDado.numeroMovimientos;
import static medievil.Tablero.lbPersonaje11;
import static medievil.Tablero.lbPersonaje12;
import static medievil.Tablero.lbPersonaje13;
import static medievil.Tablero.lbPersonaje21;
import static medievil.Tablero.lbPersonaje22;
import static medievil.Tablero.lbPersonaje23;
import static medievil.Tablero.pnlAJuego;
import static medievil.Tablero.turno;
import static medievil.Tablero.turnoPersonaje1;
import static medievil.Tablero.turnoPersonaje2;
/**
 *
 * @author Luis Enrique
 */
public class MovimientoArriba extends Thread{
    
    public Icon fondoJ1;
    public Icon fondoJ2;
    
    public void run(){
        
        
        
        
        if(turno == 1 ){
                    
                    for (int i = 0; i < numeroMovimientos; i++) {
            try {
                Thread.sleep(500);
                lbMapa[posicionJugador1X][posicionJugador1Y].setIcon(null);
                pnlAJuego.repaint();
                posicionJugador1X-=1;
                
                //condicionales 
                if(posicionJugador1X<0){
                   
                    posicionJugador1X = lbMapa.length/2;
                    posicionJugador1Y = lbMapa.length/2;
                    i = numeroMovimientos-1;
                    if(lbMapa[posicionJugador1X][posicionJugador1Y].getIcon()!=null){
                        
                    }
                    
                }
               
                lbMapa[posicionJugador1X][posicionJugador1Y].setIcon(turnosJ1());
                pnlAJuego.repaint();
            } catch (InterruptedException ex) {
                Logger.getLogger(MovimientoArriba.class.getName()).log(Level.SEVERE, null, ex);
            }
            
           
        }       
                }else{
            for (int i = 0; i < numeroMovimientos; i++) {
                
                try {
                    Thread.sleep(500);
                    
                    lbMapa[posicionJugador2X][posicionJugador2Y].setIcon(null);
                    pnlAJuego.repaint();
                    posicionJugador2X-=1;
                     //condicionales 
                if(posicionJugador2X<0){
                   
                    posicionJugador2X = lbMapa.length/2;
                    posicionJugador2Y = lbMapa.length/2;
                    i = numeroMovimientos-1;
                    if(lbMapa[posicionJugador2X][posicionJugador2Y].getIcon()!=null){
                        
                    }
                    
                }
                
                
                    lbMapa[posicionJugador2X][posicionJugador2Y].setIcon(turnosJ2());
                    pnlAJuego.repaint();
                } catch (InterruptedException ex) {
                    Logger.getLogger(MovimientoArriba.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                    
                    
                }
        
                    
        
    }
    
     public Icon turnosJ1(){
        
        String imagenP1  = "";
        
        
        switch (turnoPersonaje1){
            case 0:
                if(lbPersonaje11.getText().equals("Mago")){
                    imagenP1 = "/Imagenes/mago.png";
                }else if(lbPersonaje11.getText().equals("Princesa")){
                    imagenP1 = "/Imagenes/princesa.png";
                }else{
                    imagenP1 = "/Imagenes/caballero.png";
                }
                break;
            case 1:
                if(lbPersonaje12.getText().equals("Mago")){
                    imagenP1 = "/Imagenes/mago.png";
                }else if(lbPersonaje12.getText().equals("Princesa")){
                    imagenP1 = "/Imagenes/princesa.png";
                }else{
                    imagenP1 = "/Imagenes/caballero.png";
                }
                break;
            case 2:
                if(lbPersonaje13.getText().equals("Mago")){
                    imagenP1 = "/Imagenes/mago.png";
                }else if(lbPersonaje13.getText().equals("Princesa")){
                    imagenP1 = "/Imagenes/princesa.png";
                }else{
                    imagenP1 = "/Imagenes/caballero.png";
                }
                break;
        }
        
        ImageIcon imagenJ1 = new ImageIcon(getClass().getResource(imagenP1));
         fondoJ1 = new ImageIcon(imagenJ1.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        
        return fondoJ1;
    }
     
     public Icon turnosJ2(){
        
        String imagenP2  = "";
        
        
        switch (turnoPersonaje2){
            case 0:
                if(lbPersonaje21.getText().equals("Mago")){
                    imagenP2 = "/Imagenes/mago2.png";
                }else if(lbPersonaje21.getText().equals("Princesa")){
                    imagenP2 = "/Imagenes/princesa2.png";
                }else{
                    imagenP2 = "/Imagenes/caballero2.png";
                }
                break;
            case 1:
                if(lbPersonaje22.getText().equals("Mago")){
                    imagenP2 = "/Imagenes/mago2.png";
                }else if(lbPersonaje22.getText().equals("Princesa")){
                    imagenP2 = "/Imagenes/princesa2.png";
                }else{
                    imagenP2 = "/Imagenes/caballero2.png";
                }
                break;
            case 2:
                if(lbPersonaje23.getText().equals("Mago")){
                    imagenP2 = "/Imagenes/mago2.png";
                }else if(lbPersonaje23.getText().equals("Princesa")){
                    imagenP2 = "/Imagenes/princesa2.png";
                }else{
                    imagenP2 = "/Imagenes/caballero2.png";
                }
                break;
        }
        
        ImageIcon imagenJ1 = new ImageIcon(getClass().getResource(imagenP2));
        fondoJ2 = new ImageIcon(imagenJ1.getImage().getScaledInstance(dimensionLabelX, dimensionLabelY, Image.SCALE_DEFAULT));
        
        return fondoJ2;
    }
}
