/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medievil;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
//static

import static medievil.Menu.menu;
/**
 *
 * @author Luis Enrique
 */
public class Records extends JPanel implements ActionListener {
    
    public JLabel lbRecords = new JLabel("TOP 10 Mejores Jugadores");
    public JLabel lbFondo = new JLabel();
    public JButton btnRegresar = new JButton("Regresar al Menu");

    //tabla records
    public JTable records = new JTable() {
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    
    public static DefaultTableModel modelo = new DefaultTableModel();
    JScrollPane barra = new JScrollPane(records);
    
    public int fila, columna;
    
    public Records() {
        
        this.setSize(950, 700);
        this.setLayout(null);
        //fondo
        lbFondo.setBounds(0, 0, 950, 700);
        //imagen a label
        ImageIcon imagen = new ImageIcon(getClass().getResource("/Imagenes/fondomenu.jpg"));
        Icon fondom = new ImageIcon(imagen.getImage().getScaledInstance(lbFondo.getWidth(), lbFondo.getHeight(), Image.SCALE_DEFAULT));
        lbFondo.setIcon(fondom);
        //
        lbRecords.setBounds(250, 10, 550, 40);
        lbRecords.setFont(new java.awt.Font("Algerian", 0, 36));
        lbRecords.setForeground(new java.awt.Color(255, 255, 255));
        
        btnRegresar.setBounds(410, 600, 150, 30);
        btnRegresar.addActionListener(this);

        //tabla records
        records.setModel(modelo);
        records.getTableHeader().setReorderingAllowed(false);
        records.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {                
                
                fila = records.rowAtPoint(e.getPoint());
                columna = records.columnAtPoint(e.getPoint());
                if ((fila > -1) && (columna > -1)) {
                    
                }
            }
        });

        //añadir columnas
        modelo.addColumn("Nombre Jugador");
        modelo.addColumn("Orden Personajes");
        modelo.addColumn("Numero de Vidas");
        modelo.addColumn("Duracion de Partida");

        //
        barra.setPreferredSize(new Dimension(800, 500));
        barra.setBounds(30, 60, 900, 500);

        //
        this.add(lbRecords);
        this.add(barra);
        this.add(btnRegresar);
        this.add(lbFondo);
        this.setVisible(false);
    }
    
    @Override
    public void actionPerformed(ActionEvent evento) {
        
        if (evento.getSource() == btnRegresar) {
            
            this.setVisible(false);
            menu.setVisible(true);
        }

        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
